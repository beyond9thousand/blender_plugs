# create mesh

# add numpy array as verts to bmesh
# add numpy array as faces to bmesh

# get verts as numpy array
# get vertex groups
# create vertex group
# add verts to vertex group
# verts in vertex group
# delete verts in vertex group
# delete verts

# recalculate_face_normals

